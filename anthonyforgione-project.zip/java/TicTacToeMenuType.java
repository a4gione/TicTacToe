
/**
 *
 * @author AnthonyF
 */
public enum TicTacToeMenuType {
    HELP,
    NEW_GAME,
    PLAY_AGAIN;
}
